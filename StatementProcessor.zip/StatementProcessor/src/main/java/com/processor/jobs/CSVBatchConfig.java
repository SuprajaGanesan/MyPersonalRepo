package com.processor.jobs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import com.processor.model.CSVReport;
import com.processor.model.FinalReport;

@Configuration
@EnableBatchProcessing
public class CSVBatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Value("/input*.csv")
	private Resource[] inputResources;
	
	private Resource outputResource = new FileSystemResource("output/outputData.csv");

	private static final Logger log = LoggerFactory.getLogger(CSVBatchConfig.class);

	@Bean
	public Job readCSVFilesJob() {
		return jobBuilderFactory.get("readCSVFilesJob").incrementer(new RunIdIncrementer()).start(step1()).next(step3()).build();
	}

	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<CSVReport, CSVReport>chunk(100).reader(multiResourceItemReader())
				.writer(writer()).build();
	}
	@Bean
	public Step step3() {
		return stepBuilderFactory.get("step3").<CSVReport, CSVReport>chunk(100)
				.reader(multiResourceItemReader())
				.writer(flatFileWriter()).build();
	}

	@Bean
	public MultiResourceItemReader<CSVReport> multiResourceItemReader() {
		MultiResourceItemReader<CSVReport> resourceItemReader = new MultiResourceItemReader<CSVReport>();
		Resource[] resources = null;
		ResourcePatternResolver patternResolver = new PathMatchingResourcePatternResolver();
		try {
//            resources = patternResolver.getResources("C://Users//SuprajaGanesan//Desktop//CTS Assignment//raboassignment//raboassignment//*.csv");
			resources = patternResolver.getResources("\\input\\*.csv");
		} catch (IOException e) {
			e.printStackTrace();
		}
		resourceItemReader.setResources(resources);
		resourceItemReader.setDelegate(reader());
		return resourceItemReader;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public FlatFileItemReader<CSVReport> reader() {
		// Create reader instance
		FlatFileItemReader<CSVReport> reader = new FlatFileItemReader<CSVReport>();

		// Set number of lines to skips. Use it if file has header rows.
		reader.setLinesToSkip(1);

		// Configure how each line will be parsed and mapped to different values
		reader.setLineMapper(new DefaultLineMapper<CSVReport>() {
			{
				// 3 columns in each row
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "txnRefId", "accountNumber", "description", "startBalance", "mutation",
								"endBalance" });
					}
				});
				// Set values in Pojo class
				setFieldSetMapper(new BeanWrapperFieldSetMapper<CSVReport>() {
					{
						setTargetType(CSVReport.class);
					}
				});
			}
		});
		return reader;
	}

	@Bean
	public ConsoleItemWriter<CSVReport> writer() {
		return new ConsoleItemWriter<CSVReport>();
	}

	public class ConsoleItemWriter<T> implements ItemWriter<T> {
		@Override
		public void write(List<? extends T> items) throws Exception {
			for (T item : items) {
				log.info("Report Data" + item);
			}
			this.validateTransactions(items);
			this.validateTxnRefId(items);
		}

		public void validateTransactions(List<? extends T> items) throws Exception {
			log.info("Validating Transactions..");
			List<CSVReport> transactions = (List<CSVReport>) items;
			List<FinalReport> report = new ArrayList<FinalReport>();
			for (CSVReport record : transactions) {
				Double endBalance = Double.valueOf(record.getStartBalance()) + Double.valueOf(record.getMutation());
				if (!endBalance.equals(Double.valueOf(record.getEndBalance()))) {
					log.info("INVALID TRANSACTION FOUND !!!!");
					log.info("INVALID Transaction Reference: " + record.getTxnRefId());
					FinalReport finalReport = new FinalReport();
					finalReport.setTransactionRef(record.getTxnRefId());
					finalReport.setDescription("Incorrect End Balance Calculation.");
					report.add(finalReport);
				}
			}
		}

		public void validateTxnRefId(List<? extends T> items) throws Exception {
			log.info("Validation Reference Ids..");
			List<CSVReport> transactions = (List<CSVReport>) items;
			Set<String> set = new HashSet<String>();
			for (CSVReport record : transactions) {
				set.add(record.getTxnRefId());
			}
			if (transactions.size() != set.size()) {
				log.info("DUPLICATE TRANSACTION REFERENCE ID FOUND !!!!");
			}
		}
	}
	
	@Bean
    public FlatFileItemWriter<CSVReport> flatFileWriter() 
    {
        //Create writer instance
        FlatFileItemWriter<CSVReport> writer = new FlatFileItemWriter<>();
         
        //Set output file location
        writer.setResource(outputResource);
         
        //All job repetitions should "append" to same output file
        writer.setAppendAllowed(true);
         
        //Name field values sequence based on object properties 
        writer.setLineAggregator(new DelimitedLineAggregator<CSVReport>() {
        	{
                setDelimiter(",");
                setFieldExtractor(new BeanWrapperFieldExtractor<CSVReport>() {
                    {
                        setNames(new String[] { "txnRefId", "description" });
                    }
                });
        	}
        });
        return writer;
    }
}
