package com.processor.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement(name="records")
public class XMLReport {
	
	 Records records;

	/**
	 * @return the records
	 */
	public Records getRecords() {
		return records;
	}

	/**
	 * @param records the records to set
	 */
	public void setRecords(Records records) {
		this.records = records;
	}

	@Override
	public String toString() {
		return "XMLReport [records=" + records + "]";
	}	
	 
	 
}