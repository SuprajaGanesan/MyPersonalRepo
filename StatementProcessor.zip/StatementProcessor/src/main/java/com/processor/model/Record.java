package com.processor.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="record")
public class Record {
	private String accountNumber;
	 private String description;
	 private String startBalance;
	 private String mutation;
	 private String endBalance;
	 private String _reference;


	 // Getter Methods 

	 public String getAccountNumber() {
	  return accountNumber;
	 }

	 public String getDescription() {
	  return description;
	 }

	 public String getStartBalance() {
	  return startBalance;
	 }

	 public String getMutation() {
	  return mutation;
	 }

	 public String getEndBalance() {
	  return endBalance;
	 }

	 public String get_reference() {
	  return _reference;
	 }

	 // Setter Methods 
	 @XmlElement
	 public void setAccountNumber(String accountNumber) {
	  this.accountNumber = accountNumber;
	 }
	 @XmlElement
	 public void setDescription(String description) {
	  this.description = description;
	 }
	 @XmlElement
	 public void setStartBalance(String startBalance) {
	  this.startBalance = startBalance;
	 }
	 @XmlElement
	 public void setMutation(String mutation) {
	  this.mutation = mutation;
	 }
	 @XmlElement
	 public void setEndBalance(String endBalance) {
	  this.endBalance = endBalance;
	 }
	 @XmlElement
	 public void set_reference(String _reference) {
	  this._reference = _reference;
	 }

	@Override
	public String toString() {
		return "Record [accountNumber=" + accountNumber + ", description=" + description + ", startBalance="
				+ startBalance + ", mutation=" + mutation + ", endBalance=" + endBalance + ", _reference=" + _reference
				+ "]";
	}

	 
}
