package com.processor.model;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="records")
public class Records {

	Record RecordObject;

	// Getter Methods

	public Record getRecord() {
		return RecordObject;
	}

	// Setter Methods
	@XmlElement
	public void setRecord(Record recordObject) {
		this.RecordObject = recordObject;
	}

	@Override
	public String toString() {
		return "Records [RecordObject=" + RecordObject + "]";
	}
	
}