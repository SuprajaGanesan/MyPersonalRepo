package com.processor.model;

public class FinalReport {
	String transactionRef;
	String description;
	/**
	 * @return the transactionRef
	 */
	public String getTransactionRef() {
		return transactionRef;
	}
	/**
	 * @param transactionRef the transactionRef to set
	 */
	public void setTransactionRef(String transactionRef) {
		this.transactionRef = transactionRef;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
