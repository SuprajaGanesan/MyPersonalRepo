package com.processor.model;

public class CSVReport {
	
	private String txnRefId;
	private String accountNumber;
	private String startBalance;
	private String mutation;
	private String description;
	private String endBalance;
	
	public CSVReport() {
		
	}
	
	/**
	 * @param txnRefId
	 * @param accountNumber
	 * @param startBalance
	 * @param mutation
	 * @param description
	 * @param endBalance
	 */
	public CSVReport(String txnRefId, String accountNumber, String startBalance, String mutation, String description,
			String endBalance) {
		super();
		this.txnRefId = txnRefId;
		this.accountNumber = accountNumber;
		this.startBalance = startBalance;
		this.mutation = mutation;
		this.description = description;
		this.endBalance = endBalance;
	}
	public String getTxnRefId() {
		return txnRefId;
	}
	public void setTxnRefId(String txnRefId) {
		this.txnRefId = txnRefId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getStartBalance() {
		return startBalance;
	}
	public void setStartBalance(String startBalance) {
		this.startBalance = startBalance;
	}
	public String getMutation() {
		return mutation;
	}
	public void setMutation(String mutation) {
		this.mutation = mutation;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEndBalance() {
		return endBalance;
	}
	public void setEndBalance(String endBalance) {
		this.endBalance = endBalance;
	}

	@Override
	public String toString() {
		return "CSVReport [txnRefId=" + txnRefId + ", accountNumber=" + accountNumber + ", startBalance=" + startBalance
				+ ", mutation=" + mutation + ", description=" + description + ", endBalance=" + endBalance + "]";
	}
	
	

}
